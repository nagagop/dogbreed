/**
 * 
 */
package com.db.orm.dao;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

/**
 * @author gopic
 *
 */
@Repository
public class GenericDAOImpl implements GenericDAO {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	Session currentSession() {
		return this.sessionFactory.getCurrentSession();
	}

	/* (non-Javadoc)
	 * @see com.db.dao.GenericDAO#get(java.lang.Class, java.lang.Long)
	 */
	public <T> T get(Class<T> type, Long id) {
		return (T) this.currentSession().get(type, id);
	}

	/* (non-Javadoc)
	 * @see com.db.dao.GenericDAO#saveOrUpdate(java.lang.Object)
	 */
	public <T> void saveOrUpdate(T o) {
		this.currentSession().saveOrUpdate(o);
	}

	/**
	 * 
	 * @param type
	 * @param nameValue
	 */
	public List<?> getObjectsWithCriteria(Class<?> type, DAOContext context) {

		List<?> list = null;
		Criteria query = null;

		query = this.currentSession().createCriteria(type);

		/* Pagination parameters are populated */
		this.populatePaginationParams(context.getNameValue(), query);

		this.getQueryCriteria(context, query);
		
		list = query.list();
		
		return list;
	}

	/**
	 * 
	 * @param context
	 * @param query
	 */
	private void getQueryCriteria(DAOContext context, Criteria query) {
		
		/* Create the aliases on Criteria object */
		this.createAliases(context.getAlias(), query);

		/* Add the criteria parameters */
		this.addCriteriaParams(context.getNameValue(), query);
		
		/* Add the order by clause */
		this.populateOrderClause(context.getOrder(), query);
	}

	/**
	 * @param nameValue
	 * @param query
	 */
	private void addCriteriaParams(Map<String, Object> nameValue, Criteria query) {
		
		String key = null;
		Object value = null;
		Iterator<String> valuesItr = null;
		
		if (!CollectionUtils.isEmpty(nameValue)) {
			valuesItr = nameValue.keySet().iterator();
			while (valuesItr.hasNext()) {
				key = valuesItr.next();
				value = nameValue.get(key);
				query.add(this.getExpressionByType(key, value));
			}
		}
	}

	/**
	 * @param alias
	 * @param query
	 */
	private void createAliases(Map<String, String> alias, Criteria query) {
		
		String aliasKey = null;
		String aliasValue = null;
		Iterator<String> itAlias = null;
		
		if (!CollectionUtils.isEmpty(alias)) {
			itAlias = alias.keySet().iterator();
			while (itAlias.hasNext()) {
				aliasKey = itAlias.next();
				aliasValue = alias.get(aliasKey);
				query.createAlias(aliasKey, aliasValue);
			}
		}
	}

	/**
	 * 
	 * @param order
	 * @param query
	 */
	private void populateOrderClause(Map<String, String> order, Criteria query) {
		
		String param = null;
		String orderType = null;
		Iterator<String> orderItr = null;
		
		if (!CollectionUtils.isEmpty(order)) {			
			orderItr = order.keySet().iterator();			
			while (orderItr.hasNext()) {				
				param = (String) orderItr.next();
				orderType = order.get(param);
				
				if (org.apache.commons.lang3.StringUtils.isNotEmpty(orderType)) {
					if (orderType.equals("ASC")) {
						query.addOrder(Order.asc(param));
					} else if (orderType.equals("DSC")) {
						query.addOrder(Order.desc(param));
					}
				}
			}
		}
	}

	/**
	 * 
	 * @param nameValue
	 * @param query
	 */
	private void populatePaginationParams(Map<String, Object> nameValue,
			Criteria query) {
		
		int firstRecord = 0;
		int numberofRecords = 0;
		
		if(nameValue.containsKey("firstRecord") &&
				nameValue.containsKey("numberofRecords")) {
			
			firstRecord = 
				((Integer)nameValue.get("firstRecord")).intValue();
			numberofRecords = 
				((Integer)nameValue.get("numberofRecords")).intValue();
			
			query.setFirstResult(firstRecord);
			query.setMaxResults(numberofRecords);
			
			nameValue.remove("firstRecord");
			nameValue.remove("numberofRecords");
		}
	}

	/**
	 * 
	 * @param key
	 * @param value
	 * @return
	 */
	private Criterion getExpressionByType(String key, Object value) {
		
		Criterion expression = null;
		
		if (value instanceof Collection) {
			expression = Restrictions.in(key, (Collection<?>) value);
		} else {
			expression = Restrictions.eq(key, value);
		}
		
		return expression;
	}
}
