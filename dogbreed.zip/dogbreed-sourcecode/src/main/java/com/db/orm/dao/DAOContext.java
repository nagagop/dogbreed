/**
 * 
 */
package com.db.orm.dao;

import java.util.Map;

/**
 * @author Gopi Chitturi
 *
 */
public interface DAOContext {

	/**
	 * 
	 * @return
	 */
	Map<String, Object> getNameValue();
	
	/**
	 * 
	 * @return
	 */
	Map<String, String> getAlias();
	
	/**
	 * 
	 * @return
	 */
	Map<String, String> getOrder();
	
	DAOContext getDetachedCriteriaContext();
	
	
}
