/**
 * 
 */
package com.db.orm.dao;

import java.util.List;

/**
 * @author gopic
 *
 */
public interface GenericDAO {
	
	<T> T get(final Class<T> type, final Long id);
	
	<T> void saveOrUpdate(final T o);
	
	List<?> getObjectsWithCriteria(Class<?> type, DAOContext context);
}