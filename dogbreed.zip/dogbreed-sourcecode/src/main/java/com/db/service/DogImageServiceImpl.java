/**
 * 
 */
package com.db.service;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.db.orm.dao.DAOContextImpl;
import com.db.orm.dao.GenericDAO;
import com.db.orm.model.DogImage;
import com.db.view.model.BreedPOJO;
import com.db.view.model.ImagePOJO;

/**
 * @author gopic
 *
 */
@Service("dogImageService")
@Transactional
public class DogImageServiceImpl implements DogImageService {

	private final Logger log = LogManager.getLogger(getClass());
	
	@Autowired
	private GenericDAO genericDAO;
	
	@Autowired
	private DAOContextImpl daoContext;

	/**
	 * @return the genericDAO
	 */
	public GenericDAO getGenericDAO() {
		return genericDAO;
	}

	/**
	 * @param genericDAO the genericDAO to set
	 */
	public void setGenericDAO(GenericDAO genericDAO) {
		this.genericDAO = genericDAO;
	}

	/* (non-Javadoc)
	 * @see com.db.service.DogImageService#getDogImages(long, long)
	 */
	@Transactional(propagation=Propagation.REQUIRED, readOnly=true)
	public List<BreedPOJO> getDogImages(Map<String, ?> params) {
		
		Collection<DogImage> images = null;
		Map<String,Object> nameValueMap = null;
		Map<String, String> aliasMap = null;

		nameValueMap = new HashMap<>(Collections.EMPTY_MAP);
		if (!CollectionUtils.isEmpty(params)) {
			
			aliasMap = new HashMap<String, String>();
			aliasMap.put("dog", "dog");
			aliasMap.put("dog.breed", "breed");
			this.daoContext.setAlias(aliasMap);

			if (params.containsKey("breedId")) {
				nameValueMap.put("breed.breedId", params.get("breedId"));
			}

			if (params.containsKey("imageId")) {
				nameValueMap.put("dogImageId", params.get("imageId"));
			}
		}		
		
		this.daoContext.setNameValue(nameValueMap);
				
		images = (Collection<DogImage>) this.genericDAO.getObjectsWithCriteria(DogImage.class, daoContext);
		
		List<ImagePOJO> imagePOJOs = 
				images.stream()
					.map(i-> new ImagePOJO(i.getDogImageId(), i.getDog().getDogId(), 
							i.getDog().getDogName(), i.getDog().getBreed().getBreedName(), i.getDog().getBreed().getBreedId(), 
							i.getImageUrl(), i.getUpVoteCount(), i.getDownVoteCount()))
					.collect(Collectors.toList());
		
		Map<String, List<ImagePOJO>> respMap = imagePOJOs.stream().collect(Collectors.groupingBy(ImagePOJO::getBreedName));
		
		List<BreedPOJO> breedSets = respMap.entrySet().stream().map(map -> new BreedPOJO(map.getKey(), map.getValue())).collect(Collectors.toList());
		
		log.debug("No of Images retrieved from DB: " + images.size());
		
		return breedSets;
	}

	/* (non-Javadoc)
	 * @see com.db.service.DogImageService#updateImage(long, java.lang.String)
	 */
	@Transactional(propagation=Propagation.REQUIRES_NEW, readOnly=false)
	public boolean updateImage(long imageId, String voteType) {
		
		DogImage image = this.genericDAO.get(DogImage.class, imageId);
		
		if ("UP".equalsIgnoreCase(voteType)) {
			image.setUpVoteCount(image.getUpVoteCount()+1);
		}
		
		if ("DOWN".equalsIgnoreCase(voteType)) {
			image.setDownVoteCount(image.getDownVoteCount()+1);
		}
		
		this.genericDAO.saveOrUpdate(image);
		
		return true;
	}

}
