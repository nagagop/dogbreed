/**
 * 
 */
package com.db.service;

import java.util.List;
import java.util.Map;

import com.db.view.model.BreedPOJO;
import com.db.view.model.ImagePOJO;

/**
 * @author gopic
 *
 */
public interface DogImageService {

	List<BreedPOJO> getDogImages(Map<String, ?> params);
	
	ImagePOJO updateImage(long imageId, String voteType);
}