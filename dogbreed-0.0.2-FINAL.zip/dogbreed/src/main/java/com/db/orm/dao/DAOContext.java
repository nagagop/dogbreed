/**
 * 
 */
package com.db.orm.dao;

import java.util.Map;

/**
 * @author gopic
 *
 */
public interface DAOContext {

	/**
	 * 
	 * @return
	 */
	Map<String, Object> getNameValue();
	
	/**
	 * 
	 * @return
	 */
	Map<String, String> getAlias();
	
	/**
	 * 
	 * @return
	 */
	Map<String, String> getOrder();
	
	/**
	 * 
	 * @param nameValue
	 */
	void setNameValue(Map<String, Object> nameValue);
	
	/**
	 * 
	 * @param alias
	 */
	void setAlias(Map<String, String> alias);
	
	
	/**
	 * 
	 * @param order
	 */
	void setOrder(Map<String, String> order);
}