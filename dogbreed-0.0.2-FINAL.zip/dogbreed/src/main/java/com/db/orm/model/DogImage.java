/**
 * 
 */
package com.db.orm.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * @author gopic
 *
 */
@Entity
@Table(name="DOG_IMAGE")
public class DogImage implements Serializable {

	@Transient
	private static final long serialVersionUID = 6716407195522917406L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="DOG_IMAGE_ID", nullable=false, unique=true)
	private long dogImageId;
	
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="DOG_ID", nullable=false)
	private Dog dog;
	
	@Column(name="IMAGE_URL", nullable=false)
	private String imageUrl;
	
	@Column(name="VOTE_UP_COUNT", nullable=false)
	private long upVoteCount;
	
	@Column(name="VOTE_DOWN_COUNT", nullable=false)
	private long downVoteCount;

	/**
	 * @return the dogImageId
	 */
	public long getDogImageId() {
		return dogImageId;
	}

	/**
	 * @param dogImageId the dogImageId to set
	 */
	public void setDogImageId(long dogImageId) {
		this.dogImageId = dogImageId;
	}

	/**
	 * @return the dog
	 */
	public Dog getDog() {
		return dog;
	}

	/**
	 * @param dog the dog to set
	 */
	public void setDog(Dog dog) {
		this.dog = dog;
	}

	/**
	 * @return the imageUrl
	 */
	public String getImageUrl() {
		return imageUrl;
	}

	/**
	 * @param imageUrl the imageUrl to set
	 */
	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	/**
	 * @return the upVoteCount
	 */
	public long getUpVoteCount() {
		return upVoteCount;
	}

	/**
	 * @param upVoteCount the upVoteCount to set
	 */
	public void setUpVoteCount(long upVoteCount) {
		this.upVoteCount = upVoteCount;
	}

	/**
	 * @return the downVoteCount
	 */
	public long getDownVoteCount() {
		return downVoteCount;
	}

	/**
	 * @param downVoteCount the downVoteCount to set
	 */
	public void setDownVoteCount(long downVoteCount) {
		this.downVoteCount = downVoteCount;
	}
	
	/**
	 * 
	 * @return
	 */
	public String getBreedName() {
		return this.dog.getBreed().getBreedName();
	}
}
