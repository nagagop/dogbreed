/**
 * 
 */
package com.db.orm.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * @author gopic
 *
 */
@Entity
@Table(name="DOG")
public class Dog implements Serializable {

	@Transient
	private static final long serialVersionUID = -9217852481650766841L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="dog_id", nullable=false, unique=true)
	private long dogId;
	
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="dog_breed_id", nullable=false)
	private Breed breed;
	
	@Column(name="DOG_NAME", nullable=true, unique=false)
	private String dogName;

	@OneToMany(mappedBy="dog", fetch=FetchType.EAGER)
	private Set<DogImage> dogImages;
	
	/**
	 * @return the dogId
	 */
	public long getDogId() {
		return dogId;
	}

	/**
	 * @param dogId the dogId to set
	 */
	public void setDogId(long dogId) {
		this.dogId = dogId;
	}

	/**
	 * @return the breed
	 */
	public Breed getBreed() {
		return breed;
	}

	/**
	 * @param breed the breed to set
	 */
	public void setBreed(Breed breed) {
		this.breed = breed;
	}

	/**
	 * @return the dogName
	 */
	public String getDogName() {
		return dogName;
	}

	/**
	 * @param dogName the dogName to set
	 */
	public void setDogName(String dogName) {
		this.dogName = dogName;
	}

	/**
	 * @return the dogImages
	 */
	public Set<DogImage> getDogImages() {
		return dogImages;
	}

	/**
	 * @param dogImages the dogImages to set
	 */
	public void setDogImages(Set<DogImage> dogImages) {
		this.dogImages = dogImages;
	}

}
