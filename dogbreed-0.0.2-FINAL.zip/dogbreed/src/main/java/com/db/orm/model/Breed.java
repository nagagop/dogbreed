/**
 * 
 */
package com.db.orm.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * @author gopic
 *
 */
@Entity
@Table(name="DOG_BREED")
public class Breed implements Serializable {

	@Transient
	private static final long serialVersionUID = 6940268293500410905L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="DOG_BREED_ID", nullable=false, unique=true)
	private long breedId;
	
	@Column(name="DOG_BREED_NAME")
	private String breedName;
	
	@OneToMany(mappedBy="breed", fetch=FetchType.EAGER)
	private Set<Dog> dogs;

	/**
	 * @return the breedId
	 */
	public long getBreedId() {
		return breedId;
	}

	/**	 * @param breedId the breedId to set
	 */
	public void setBreedId(long breedId) {
		this.breedId = breedId;
	}

	/**
	 * @return the breedName
	 */
	public String getBreedName() {
		return breedName;
	}

	/**
	 * @param breedName the breedName to set
	 */
	public void setBreedName(String breedName) {
		this.breedName = breedName;
	}

	/**
	 * @return the dogs
	 */
	public Set<Dog> getDogs() {
		return dogs;
	}

	/**
	 * @param dogs the dogs to set
	 */
	public void setDogs(Set<Dog> dogs) {
		this.dogs = dogs;
	}
}
