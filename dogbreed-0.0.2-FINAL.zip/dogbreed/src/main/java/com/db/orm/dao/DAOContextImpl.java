/**
 * 
 */
package com.db.orm.dao;

import java.util.Map;

import org.springframework.stereotype.Component;

/**
 * @author gopic
 *
 */
@Component
public class DAOContextImpl implements DAOContext {

	private Map<String, Object> nameValue = null;
	private Map<String, String> alias = null;
	private Map<String, String> order = null;
	
	// Added to hold the Detached Criteria context
	private DAOContextImpl detachedCriteriaContext;
	
	/**
	 * @return the detachedCriteriaContext
	 */
	public DAOContextImpl getDetachedCriteriaContext() {
		return detachedCriteriaContext;
	}
	/**
	 * @return the nameValue
	 */
	public Map<String, Object> getNameValue() {
		return nameValue;
	}
	/**
	 * @param nameValue the nameValue to set
	 */
	public void setNameValue(Map<String, Object> nameValue) {
		this.nameValue = nameValue;
	}
	/**
	 * @return the alias
	 */
	public Map<String, String> getAlias() {
		return alias;
	}
	/**
	 * @param alias the alias to set
	 */
	public void setAlias(Map<String, String> alias) {
		this.alias = alias;
	}
	/**
	 * @return the order
	 */
	public Map<String, String> getOrder() {
		return order;
	}
	/**
	 * @param order the order to set
	 */
	public void setOrder(Map<String, String> order) {
		this.order = order;
	}
}
