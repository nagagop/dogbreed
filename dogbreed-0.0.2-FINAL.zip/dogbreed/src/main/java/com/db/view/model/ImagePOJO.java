/**
 * 
 */
package com.db.view.model;

import java.io.Serializable;

/**
 * @author gopic
 *
 */
public class ImagePOJO implements Serializable, Comparable<ImagePOJO> {

	private static final long serialVersionUID = 3387853780116569906L;
	
	public ImagePOJO(long dogImageId, long dogId, String dogName, String breedName, long breedId, String imageUrl, long upVoteCount, long downVoteCount) {
		this.dogImageId = dogImageId;
		this.dogId = dogId;
		this.dogName = dogName;
		this.breedName = breedName;
		this.breedId = breedId;
		this.imageUrl = imageUrl;
		this.upVoteCount = upVoteCount;
		this.downVoteCount = downVoteCount;
	}

	private long dogImageId;
	
	private Long dogId;
	
	private String dogName;
	
	private String breedName;
	
	private Long breedId;
	
	private String imageUrl;
	
	private long upVoteCount;
	
	private long downVoteCount;

	/**
	 * @return the dogImageId
	 */
	public long getDogImageId() {
		return dogImageId;
	}

	/**
	 * @param dogImageId the dogImageId to set
	 */
	public void setDogImageId(long dogImageId) {
		this.dogImageId = dogImageId;
	}

	/**
	 * @return the dogId
	 */
	public Long getDogId() {
		return dogId;
	}

	/**
	 * @param dogId the dogId to set
	 */
	public void setDogId(Long dogId) {
		this.dogId = dogId;
	}

	/**
	 * @return the dogName
	 */
	public String getDogName() {
		return dogName;
	}

	/**
	 * @param dogName the dogName to set
	 */
	public void setDogName(String dogName) {
		this.dogName = dogName;
	}

	/**
	 * @return the breedName
	 */
	public String getBreedName() {
		return breedName;
	}

	/**
	 * @param breedName the breedName to set
	 */
	public void setBreedName(String breedName) {
		this.breedName = breedName;
	}

	/**
	 * @return the breedId
	 */
	public Long getBreedId() {
		return breedId;
	}

	/**
	 * @param breedId the breedId to set
	 */
	public void setBreedId(Long breedId) {
		this.breedId = breedId;
	}

	/**
	 * @return the imageUrl
	 */
	public String getImageUrl() {
		return imageUrl;
	}

	/**
	 * @param imageUrl the imageUrl to set
	 */
	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	/**
	 * @return the upVoteCount
	 */
	public long getUpVoteCount() {
		return upVoteCount;
	}

	/**
	 * @param upVoteCount the upVoteCount to set
	 */
	public void setUpVoteCount(long upVoteCount) {
		this.upVoteCount = upVoteCount;
	}

	/**
	 * @return the downVoteCount
	 */
	public long getDownVoteCount() {
		return downVoteCount;
	}

	/**
	 * @param downVoteCount the downVoteCount to set
	 */
	public void setDownVoteCount(long downVoteCount) {
		this.downVoteCount = downVoteCount;
	}

	@Override
	public int compareTo(ImagePOJO o) {
		
		int result = 0;
		
		/* Sort by Up Vote count in descending order */
		result = Long.compare(o.upVoteCount, this.upVoteCount);
		
		/* If Up vote count is same, sort by down vote count in ascending order */
		if (result == 0) {
			result = Long.compare(this.downVoteCount, o.downVoteCount);
		}
		
		/* If both Up and Down vote count are same, sort by Image id in descending order */
		if (result == 0) {
			result = Long.compare(o.dogImageId, this.dogImageId);
		}
		
		return result;
	}
}
