/**
 * 
 */
package com.db.view.model;

import java.io.Serializable;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

/**
 * @author gopic
 *
 */
public class BreedPOJO implements Serializable {

	private static final long serialVersionUID = 6940268293500410905L;

	private String breedName;
	
	private Set<ImagePOJO> images;

	public BreedPOJO(String key, List<ImagePOJO> value) {
		this.breedName = key;
		this.images = new TreeSet<>(value);
	}

	/**
	 * @return the breedName
	 */
	public String getBreedName() {
		return breedName;
	}

	/**
	 * @param breedName the breedName to set
	 */
	public void setBreedName(String breedName) {
		this.breedName = breedName;
	}

	/**
	 * @return the images
	 */
	public Set<ImagePOJO> getImages() {
		return images;
	}

	/**
	 * @param images the images to set
	 */
	public void setImages(Set<ImagePOJO> images) {
		this.images = images;
	}

}
