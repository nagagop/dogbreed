/**
 * 
 */
package com.db.controller;

import java.util.Collections;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.db.service.DogImageService;
import com.db.view.model.BreedPOJO;

/**
 * @author gopic
 *
 */
public class ImageViewController {
	
	private final Logger log = LogManager.getLogger(getClass());
	
	@Autowired
	private DogImageService dogImageService;
	
	/**
	 * @return the dogImageService
	 */
	public DogImageService getDogImageService() {
		return dogImageService;
	}

	/**
	 * @param dogImageService the dogImageService to set
	 */
	public void setDogImageService(DogImageService dogImageService) {
		this.dogImageService = dogImageService;
	}

	@RequestMapping("/")
	public ModelAndView getImages(ModelAndView model) {
		
		List<BreedPOJO> imagePOJOs = null;

		imagePOJOs = this.dogImageService.getDogImages(Collections.EMPTY_MAP);
		model.addObject(imagePOJOs);
		model.setViewName("index");
		
		return model;
	}
}