/**
 * 
 */
package com.db.controller;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.db.service.DogImageService;
import com.db.view.model.BreedPOJO;
import com.db.view.model.ImagePOJO;

/**
 * @author gopic
 *
 */
@RestController
@RequestMapping("/dog/images")
public class DogImageController {
	
	private final Logger log = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private DogImageService dogImageService;
	
	/**
	 * @return the dogImageService
	 */
	public DogImageService getDogImageService() {
		return dogImageService;
	}

	/**
	 * @param dogImageService the dogImageService to set
	 */
	public void setDogImageService(DogImageService dogImageService) {
		this.dogImageService = dogImageService;
	}

	/**
	 * 
	 * @param breedId
	 * @param imageId
	 * @return
	 */
	@GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getImages(@RequestParam(name="breedId", required=false) String breedId, 
							@RequestParam(name="imageId", required=false) String imageId) {
		
		log.debug("entered getImage method");
		Map<String, Long> params = null;
		List<BreedPOJO> imagePOJOs = null;
		ResponseEntity<?> response = null;
		
		params = this.validateAndConvertRequestParams(breedId, imageId);
		Long status = params.get("status");
		
		if (status != null && status == -1) {
			response = new ResponseEntity<>("Both BreedId and ImageId cannot be passed in the request", HttpStatus.BAD_REQUEST);
			return response;
		}
		
		imagePOJOs = this.dogImageService.getDogImages(params);
		
		response = new ResponseEntity<>(imagePOJOs, HttpStatus.OK);
		
		return response;
	}

	/**
	 * 
	 * @param breedId
	 * @param imageId
	 * @return
	 */
	private Map<String, Long> validateAndConvertRequestParams(String breedId, String imageId) {
		
		Map<String, Long> params = null;
		Long breedIdL = null;
		Long imageIdL = null;
		
		params = new HashMap<String, Long>(Collections.<String, Long>emptyMap());
		
		if (StringUtils.isNotBlank(breedId) && StringUtils.isNotBlank(imageId)) {
			
			params.put("status", new Long(-1));
			
			return params;
		}
		
		try {
			breedIdL = NumberUtils.toLong(breedId);
		} catch (NumberFormatException e) {
			log.error("Invalid Breed Id is passed", e);
		} finally {
			if (breedIdL != 0) {
				params.put("breedId", breedIdL);
			}
		}
		
		try {
			imageIdL = NumberUtils.toLong(imageId);
		} catch (NumberFormatException e) {
			log.error("Invalid Image Id is passed", e);
		} finally {
			if (imageIdL != 0) {
				params.put("imageId", imageIdL);
			}
		}
		
		return params;
	}

	/**
	 * 
	 * @param imageId
	 * @return
	 */
	@PostMapping(path="/{imageId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> updateImage(@PathVariable Long imageId, @RequestParam(name="voteType", required=true) String voteType) {
		
		ResponseEntity<?> respEntity = null;
		ImagePOJO imagePOJO = null;
		
		log.debug("ImageId: " + imageId + " and voteType: " + voteType);
		
		imagePOJO = this.dogImageService.updateImage(imageId, voteType);
		
		if (imagePOJO != null) {
			respEntity = new ResponseEntity<>(imagePOJO, HttpStatus.OK);
		} else {
			respEntity = new ResponseEntity<>("Update failed", HttpStatus.OK);
		}
		
		return respEntity;
	}
}